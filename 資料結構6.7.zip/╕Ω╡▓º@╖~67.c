#include<stdio.h>
#include<stdlib.h>
struct node{
	int x;
	struct node* next;
};
typedef struct node* nodePointer;
nodePointer head_A=NULL;
nodePointer head_B=NULL;
nodePointer head_C=NULL;
nodePointer newnode(int x){
	nodePointer add;
	add = (nodePointer)malloc(sizeof(struct node));
	if(add!=NULL){
		add->x=x;
		add->next=NULL;
	}
}
void Insert_A(){
	int i,j,index,flag=0;
	nodePointer ptr,add;
	printf("��J�쵲��C���e\n");
	scanf("%d",&index);
	add=newnode(index);
	ptr=head_A;
	if(ptr==NULL){
		head_A=add;
	}else{
		while(ptr->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=add;
		add->next=NULL;
	}
}
void Insert_B(){
	int i,j,index;
	nodePointer ptr,add;
	printf("��J�쵲��C���e\n");
	scanf("%d",&index);
	add=newnode(index);
	ptr=head_B;
	if(ptr==NULL){
		head_B=add;
	}else{
		while(ptr->next!=NULL) ptr=ptr->next;
		ptr->next=add;
		add->next=NULL;
	}
}

void combine(){
	int i,j;
	nodePointer ptr;
	if(head_A->x < head_B->x){		//�M�w�H�֬���� 
		head_C = head_A;
		head_A = head_A->next;
	}else{
		head_C = head_B;
		head_B = head_B->next;
	}
	ptr=head_C;
	while(head_A!=NULL||head_B!=NULL){	//��AB��̪��ȳ���J�������X 
	/*���AB�j�p*/ 
		if(head_A!=NULL && head_B!=NULL && head_A->x <= head_B->x){	
			ptr->next = head_A;
			head_A = head_A->next;
			ptr = ptr->next;
		}else if(head_A!=NULL && head_B!=NULL && head_A->x >= head_B->x){
			ptr->next = head_B;
			head_B = head_B->next;
			ptr = ptr->next;
		}else if(head_A==NULL){		//���䤤�@�̥��Ƨ����p 
			while(head_B!=NULL){
				ptr->next = head_B;
				head_B = head_B->next;
				ptr=ptr->next;
			}
		}else{
			while(head_A!=NULL){
				ptr->next = head_A;
				head_A = head_A->next;
				ptr=ptr->next;
			}
		}
	}
}
void print(nodePointer head){
	int i,j;
	nodePointer ptr;
	ptr=head;
	while(ptr!=NULL){
		printf("%d\t",ptr->x);
		ptr=ptr->next;
	}
}
int main(){
	int i,j,sum;
	printf("��J�Ĥ@���쵲��C�`�Ӽ�\n");
	scanf("%d",&sum);
	while(sum--){
		Insert_A();
	}
	print(head_A);
	printf("\n");	
	printf("��J�ĤG���쵲��C�`�Ӽ�\n");
	scanf("%d",&sum);
	while(sum--){
		Insert_B();
	}
	print(head_B);
	printf("\n");
	printf("��X\n");
	combine();
	print(head_C);	
} 
